<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder {
    public function run() {
        DB::table('employees')->insert([
            ['id' => 1, 'name' => 'John Doe', 'type' => 'monthly'],
            ['id' => 2, 'name' => 'Alice Smith', 'type' => 'daily'],
            ['id' => 3, 'name' => 'Bob Brown', 'type' => 'hourly'],
        ]);

        DB::table('salary_rates')->insert([
            ['employee_id' => 1, 'monthly_rate' => 60000],
            ['employee_id' => 2, 'daily_rate' => 2200],
            ['employee_id' => 3, 'hourly_rate' => 300],
        ]);

        foreach (range(1, 26) as $day) {
            DB::table('attendance_logs')->insert([
                ['employee_id' => 1, 'work_date' => "2025-07-$day", 'worked_hours' => rand(6, 12)],
                ['employee_id' => 2, 'work_date' => "2025-07-$day", 'worked_hours' => rand(3, 9)],
                ['employee_id' => 3, 'work_date' => "2025-07-$day", 'worked_hours' => rand(1, 10)],
            ]);
        }
    }
}
