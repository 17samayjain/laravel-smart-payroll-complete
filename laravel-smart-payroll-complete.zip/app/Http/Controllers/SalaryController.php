<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\AttendanceLog;
use Carbon\Carbon;

class SalaryController extends Controller
{
    public function calculate($id, Request $request)
    {
        $month = $request->query('month');
        $startDate = Carbon::parse($month)->startOfMonth();
        $endDate = Carbon::parse($month)->endOfMonth();

        $employee = Employee::with('salaryRate')->findOrFail($id);
        $attendances = AttendanceLog::where('employee_id', $id)
            ->whereBetween('work_date', [$startDate, $endDate])->get();

        $totalHours = $attendances->sum('worked_hours');
        $totalDays = $attendances->count();
        $absents = 0;
        $halfDays = 0;
        $overtimeHours = 0;
        $otAmount = 0;
        $baseSalary = 0;
        $deductions = 0;

        foreach ($attendances as $log) {
            $h = $log->worked_hours;
            if ($h < 2) $absents++;
            elseif ($h < 4) $halfDays++;
            if ($h > 8 && $h <= 10) $overtimeHours += ($h - 8) * 1.25;
            elseif ($h > 10 && $h <= 12) $overtimeHours += (2 * 1.25) + ($h - 10) * 1.5;
            elseif ($h > 12) $overtimeHours += (2 * 1.25) + (2 * 1.5);
        }

        if ($employee->type === 'monthly') {
            $rate = $employee->salaryRate->monthly_rate;
            $perDay = $rate / $startDate->daysInMonth;
            $deductions = $absents * $perDay;
            $baseSalary = $rate - $deductions;
            $otAmount = $overtimeHours * ($perDay / 8);
        } elseif ($employee->type === 'daily') {
            $rate = $employee->salaryRate->daily_rate;
            $baseSalary = $totalDays * $rate;
            $otAmount = $overtimeHours * ($rate / 8);
        } else {
            $rate = $employee->salaryRate->hourly_rate;
            $baseSalary = $totalHours * $rate;
        }

        $finalSalary = $baseSalary + $otAmount;
        return response()->json([
            'employee' => $employee->name,
            'type' => $employee->type,
            'month' => $month,
            'total_days_worked' => $totalDays,
            'total_hours' => $totalHours,
            'absents' => $absents,
            'half_days' => $halfDays,
            'overtime_hours' => round($overtimeHours, 2),
            'overtime_amount' => round($otAmount, 2),
            'base_salary' => round($baseSalary, 2),
            'deductions' => round($deductions, 2),
            'final_salary' => round($finalSalary, 2)
        ]);
    }
}
