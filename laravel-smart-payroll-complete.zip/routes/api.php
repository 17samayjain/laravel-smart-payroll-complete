<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SalaryController;

Route::get('/salary/{employee_id}', [SalaryController::class, 'calculate']);
